
let finalScore = 0;
const index = `<p>Snake</p>
<button type="button" onclick="startSnake()">Start</button>
`

document.getElementById("components").innerHTML = index;

const snake_table = `<div id="div1"></div><div><p id="score">0</p></div>`

const startSnake = () => {
    
    console.log(`Starting snake`)
    document.getElementById("components").innerHTML = snake_table;
    tabulka = new tabulka(12,12,"div1");
    runer = new snakeRunner(10);
}
const gameOver = () => {
    let finalScoreTemp = document.getElementById('score').innerHTML;
    document.getElementById("components").innerHTML = 
    `<p>game over</p>
     <p>Your Final score is: ${finalScoreTemp}</p>
     <label for="name">Name:</label>
     <input name="name" type="text" id='input'>`;

     const submitFunction = () =>{
        let name = document.getElementById('input').value;
        let xhttp = new XMLHttpRequest();
        console.log(finalScore);
        console.log('lenght='+name.length);

        if(name===''){name='Player'}
        let JSON_sent = {"name":name,"score":finalScore};
        xhttp.onreadystatechange = function() {
          if (this.readyState == 4 && this.status == 200) {            
          }
        };
        xhttp.open("POST", "/submit_highscore", true);
      xhttp.send(JSON.stringify(JSON_sent));
        console.log(JSON.stringify(JSON_sent))
        console.log(JSON_sent)
      }   
   
     document.addEventListener('keydown', function(event) {
        if (event.code == 'Enter') {
           submitFunction();
           window.location.href = '/index' }});

    console.log(`Final score = ${finalScoreTemp}`);
    finalScore = finalScoreTemp;
    console.log(finalScore)
}