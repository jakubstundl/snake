/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
//tabulka = new tabulka(12,12,"div1");
              //x-dim,y-dim,html-id;x-y max 99

//runer = new snakeRunner(10);
              //snake-speed 1000ms/speed

